'use client'

import { useState, useEffect, useRef } from 'react'
import { motion, AnimatePresence } from 'framer-motion'
import { 
  FileText, Sparkles, Search, Download, RefreshCw, BookOpen, Loader2, 
  Copy, Check, Send, Bot, User, Trash2, MessageSquare, ArrowDown
} from 'lucide-react'
import { useTheme } from '@/context/ThemeContext'
import { useAuth } from '@/context/AuthContext'
import { useStore } from '@/lib/store'
import PageWrapper from '@/components/PageWrapper'
import GradientText from '@/components/GradientText'
import { API_URL } from '@/lib/utils'
import toast from 'react-hot-toast'

const PRIMARY = '#3B82F6'

interface Message {
  id: string
  role: 'user' | 'assistant'
  content: string
  timestamp: Date
}

export default function ResourcesPage() {
  const { theme } = useTheme()
  const { user } = useAuth()
  const { currentRoadmap, setCurrentRoadmap } = useStore()
  const isDark = theme === 'dark'
  
  const [search, setSearch] = useState('')
  const [generating, setGenerating] = useState<number | null>(null)
  const [generatedNotes, setGeneratedNotes] = useState<Record<number, string>>({})
  const [selectedTopic, setSelectedTopic] = useState<any | null>(null)
  const [copied, setCopied] = useState(false)
  const [topics, setTopics] = useState<any[]>([])
  const [loadingTopics, setLoadingTopics] = useState(true)
  const [loadingRoadmap, setLoadingRoadmap] = useState(true)
  
  // Chat states
  const [messages, setMessages] = useState<Message[]>([])
  const [input, setInput] = useState('')
  const [isLoadingChat, setIsLoadingChat] = useState(false)
  const [copiedId, setCopiedId] = useState<string | null>(null)
  const [showScrollButton, setShowScrollButton] = useState(false)
  const [activeTab, setActiveTab] = useState<'notes' | 'chat'>('notes')
  
  const messagesEndRef = useRef<HTMLDivElement>(null)
  const chatContainerRef = useRef<HTMLDivElement>(null)
  const inputRef = useRef<HTMLTextAreaElement>(null)

  // Load user's roadmap if not already loaded
  useEffect(() => {
    const loadRoadmap = async () => {
      if (!user || currentRoadmap) {
        setLoadingRoadmap(false)
        return
      }

      try {
        const { createClient } = await import('@supabase/supabase-js')
        const supabase = createClient(
          process.env.NEXT_PUBLIC_SUPABASE_URL!,
          process.env.NEXT_PUBLIC_SUPABASE_ANON_KEY!
        )

        const { data: roadmaps, error } = await supabase
          .from('roadmaps')
          .select('*')
          .eq('user_id', user.id)
          .order('created_at', { ascending: false })
          .limit(1)

        if (!error && roadmaps && roadmaps.length > 0) {
          setCurrentRoadmap(roadmaps[0])
        }
      } catch (error) {
        console.error('Error loading roadmap:', error)
      } finally {
        setLoadingRoadmap(false)
      }
    }

    loadRoadmap()
  }, [user, currentRoadmap, setCurrentRoadmap])

  // Extract topics from user's roadmap or provide fallback topics
  useEffect(() => {
    if (currentRoadmap) {
      const milestones = currentRoadmap.milestones || currentRoadmap.ai_generated_path?.milestones || []
      const extractedTopics: any[] = []
      
      milestones.forEach((milestone: any, mIndex: number) => {
        const milestoneTopics = milestone.topics || []
        milestoneTopics.forEach((topic: any, tIndex: number) => {
          extractedTopics.push({
            id: mIndex * 100 + tIndex,
            title: topic.name || topic.title,
            category: milestone.title || 'General',
            description: topic.description || ''
          })
        })
      })
      
      setTopics(extractedTopics.slice(0, 20)) // Limit to 20 topics
    } else if (!loadingRoadmap) {
      // Provide fallback topics for demonstration
      const fallbackTopics = [
        { id: 1, title: 'JavaScript Fundamentals', category: 'Programming', description: 'Variables, functions, and control structures' },
        { id: 2, title: 'React Components', category: 'Frontend', description: 'Building reusable UI components' },
        { id: 3, title: 'API Integration', category: 'Backend', description: 'Connecting frontend to backend services' },
        { id: 4, title: 'Database Design', category: 'Database', description: 'Designing efficient database schemas' },
        { id: 5, title: 'CSS Flexbox', category: 'Styling', description: 'Modern CSS layout techniques' },
        { id: 6, title: 'Node.js Basics', category: 'Backend', description: 'Server-side JavaScript development' },
        { id: 7, title: 'Git Version Control', category: 'Tools', description: 'Managing code with Git' },
        { id: 8, title: 'Responsive Design', category: 'Frontend', description: 'Creating mobile-friendly layouts' }
      ]
      setTopics(fallbackTopics)
    }
    setLoadingTopics(false)
  }, [currentRoadmap, loadingRoadmap])

  const filteredTopics = topics.filter(t => 
    t.title.toLowerCase().includes(search.toLowerCase()) ||
    t.category.toLowerCase().includes(search.toLowerCase())
  )

  const generateNotes = async (topic: any) => {
    setGenerating(topic.id)
    setSelectedTopic(topic)
    setActiveTab('notes')
    
    try {
      const response = await fetch(`${API_URL}/api/resources/generate-notes`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ 
          topic: topic.title,
          level: 'intermediate',
          format: 'detailed'
        })
      })
      
      const data = await response.json()
      
      if (data.notes) {
        setGeneratedNotes(prev => ({ ...prev, [topic.id]: data.notes }))
        toast.success('Notes generated with AI!')
      } else {
        throw new Error('Failed to generate notes')
      }
    } catch (error) {
      console.error('Error generating notes:', error)
      toast.error('Failed to generate notes. Please try again.')
    } finally {
      setGenerating(null)
    }
  }

  const copyNotes = () => {
    if (selectedTopic && generatedNotes[selectedTopic.id]) {
      navigator.clipboard.writeText(generatedNotes[selectedTopic.id])
      setCopied(true)
      setTimeout(() => setCopied(false), 2000)
      toast.success('Copied to clipboard!')
    }
  }

  // Chat functions
  const scrollToBottom = () => {
    messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' })
  }

  // Disable auto-scroll - let users control scroll position
  // useEffect(() => {
  //   if (activeTab === 'chat') {
  //     scrollToBottom()
  //   }
  // }, [messages, activeTab])

  const handleScroll = () => {
    if (chatContainerRef.current) {
      const { scrollTop, scrollHeight, clientHeight } = chatContainerRef.current
      setShowScrollButton(scrollHeight - scrollTop - clientHeight > 100)
    }
  }

  const handleInputChange = (e: React.ChangeEvent<HTMLTextAreaElement>) => {
    setInput(e.target.value)
    e.target.style.height = 'auto'
    e.target.style.height = Math.min(e.target.scrollHeight, 150) + 'px'
  }

  const copyToClipboard = (id: string, content: string) => {
    navigator.clipboard.writeText(content)
    setCopiedId(id)
    setTimeout(() => setCopiedId(null), 2000)
    toast.success('Copied to clipboard!')
  }

  const clearChat = () => {
    setMessages([])
    toast.success('Chat cleared!')
  }

  const sendMessage = async (content: string = input.trim()) => {
    if (!content || isLoadingChat) return

    const userMessage: Message = {
      id: Date.now().toString(),
      role: 'user',
      content,
      timestamp: new Date()
    }

    setMessages(prev => [...prev, userMessage])
    setInput('')
    if (inputRef.current) {
      inputRef.current.style.height = 'auto'
    }
    setIsLoadingChat(true)
    
    // Keep scroll at top when sending message
    if (chatContainerRef.current) {
      chatContainerRef.current.scrollTop = 0
    }

    try {
      const apiUrl = `${API_URL}/api/resources/chat`
      console.log('Sending request to:', apiUrl)
      
      const response = await fetch(apiUrl, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ 
          message: content,
          context: currentRoadmap?.skill?.name || 'general programming'
        })
      })

      console.log('Response status:', response.status)
      
      if (!response.ok) {
        throw new Error(`API responded with status ${response.status}`)
      }

      const data = await response.json()
      console.log('Response data:', data)

      const assistantMessage: Message = {
        id: (Date.now() + 1).toString(),
        role: 'assistant',
        content: data.response || "I'm sorry, I couldn't process that request. Please try again.",
        timestamp: new Date()
      }

      setMessages(prev => [...prev, assistantMessage])
    } catch (error: any) {
      console.error('Chat error details:', error)
      const errorMessage: Message = {
        id: (Date.now() + 1).toString(),
        role: 'assistant',
        content: `Sorry, I'm having trouble connecting right now. ${error.message || 'Please try again in a moment.'}`,
        timestamp: new Date()
      }
      setMessages(prev => [...prev, errorMessage])
      toast.error(`Connection error: ${error.message || 'Unknown error'}`)
    } finally {
      setIsLoadingChat(false)
    }
  }

  const handleKeyDown = (e: React.KeyboardEvent) => {
    if (e.key === 'Enter' && !e.shiftKey) {
      e.preventDefault()
      sendMessage()
    }
  }

  const bg = isDark ? '#09090B' : '#FFFFFF'
  const text = isDark ? '#FAFAFA' : '#09090B'
  const muted = isDark ? '#A1A1AA' : '#71717A'
  const subtle = isDark ? '#18181B' : '#F4F4F5'
  const border = isDark ? '#27272A' : '#E4E4E7'
  const accent = '#2563EB'

  return (
    <PageWrapper>
      <div className="min-h-screen pt-16 sm:pt-20 md:pt-24" style={{ background: isDark ? '#0A0A0F' : '#F8FFFE' }}>
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        
        {/* Hero Section */}
        <motion.div initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} className="text-center mb-16">
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            className="inline-flex items-center gap-2 px-3 py-1.5 rounded-full mb-6"
            style={{ 
              background: 'rgba(37,99,235,0.1)',
              border: '1px solid rgba(37,99,235,0.2)'
            }}
          >
            <Sparkles className="w-4 h-4" style={{ color: accent }} />
            <span className="text-sm font-medium" style={{ color: accent }}>AI-Powered Study Resources</span>
          </motion.div>
          
          <h1 className="text-4xl sm:text-5xl md:text-6xl lg:text-7xl font-bold mb-6" style={{ color: text }}>
            Master concepts with <GradientText>smart resources</GradientText>
          </h1>
          
          <p className="text-lg sm:text-xl leading-relaxed max-w-3xl mx-auto mb-8" style={{ color: muted }}>
            Generate AI-powered study notes for topics in your learning path or chat with our AI assistant for instant help
          </p>
        </motion.div>

        {/* Topics Count Banner */}
        {topics.length > 0 && (
          <motion.div initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: 0.1 }}
            className="mb-8 p-4 sm:p-6 bg-gradient-to-r from-blue-500 to-purple-600 rounded-2xl text-white shadow-lg"
          >
            <div className="flex items-center gap-3">
              <div className="w-10 h-10 sm:w-12 sm:h-12 bg-white/20 rounded-xl flex items-center justify-center backdrop-blur-sm">
                <Sparkles className="w-5 h-5 sm:w-6 sm:h-6 text-white" />
              </div>
              <div>
                <h3 className="font-bold text-white text-sm sm:text-base">
                  {currentRoadmap ? 'Your Learning Topics' : 'Popular Learning Topics'}
                </h3>
                <p className="text-blue-100 text-xs sm:text-sm">
                  {topics.length} topics {currentRoadmap ? 'from your roadmap' : 'available'} ready for AI notes
                </p>
              </div>
            </div>
          </motion.div>
        )}

        <div className="grid lg:grid-cols-4 gap-8">
          {/* Topics Sidebar */}
          <div className="lg:col-span-1">
            {/* Search */}
            <motion.div initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: 0.1 }} className="mb-6">
              <div className="relative group">
                <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 transition-colors group-focus-within:text-blue-500" style={{ color: muted }} />
                <input
                  type="text"
                  placeholder="Search topics..."
                  value={search}
                  onChange={(e) => setSearch(e.target.value)}
                  className="w-full pl-10 pr-4 py-3 rounded-xl text-sm outline-none transition-all border-0 focus:ring-2 focus:ring-blue-500/30 focus:scale-[1.02]"
                  style={{ 
                    background: isDark ? 'rgba(255,255,255,0.05)' : 'rgba(0,0,0,0.03)',
                    color: text
                  }}
                />
              </div>
            </motion.div>

            {/* Topics List */}
            <motion.div initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: 0.2 }} className="space-y-1">
              <h3 className="text-xs uppercase tracking-wider font-bold mb-3 opacity-60" style={{ color: text }}>Topics</h3>
              {loadingTopics ? (
                <div className="space-y-2">
                  {[1, 2, 3, 4, 5].map((i) => (
                    <div key={i} className="animate-pulse">
                      <div className="h-12 rounded-lg" style={{ background: isDark ? 'rgba(255,255,255,0.05)' : 'rgba(0,0,0,0.03)' }} />
                    </div>
                  ))}
                </div>
              ) : filteredTopics.length === 0 ? (
                <div className="text-center py-8">
                  <p className="text-sm" style={{ color: muted }}>No topics found</p>
                </div>
              ) : (
                filteredTopics.map((topic, i) => (
                <motion.button
                  key={topic.id}
                  initial={{ opacity: 0, x: -20 }}
                  animate={{ opacity: 1, x: 0 }}
                  transition={{ delay: 0.03 * i }}
                  onClick={() => generatedNotes[topic.id] ? (setSelectedTopic(topic), setActiveTab('notes')) : generateNotes(topic)}
                  disabled={generating === topic.id}
                  className="w-full group flex items-center gap-3 p-3 rounded-lg text-left transition-all hover:translate-x-1"
                  style={{ 
                    background: selectedTopic?.id === topic.id && activeTab === 'notes' ? 'linear-gradient(135deg, #3B82F6, #1D4ED8)' : 'transparent',
                    color: selectedTopic?.id === topic.id && activeTab === 'notes' ? '#fff' : text
                  }}
                >
                  <div 
                    className="w-8 h-8 rounded-lg flex items-center justify-center flex-shrink-0 transition-all" 
                    style={{ 
                      background: selectedTopic?.id === topic.id && activeTab === 'notes' ? 'rgba(255,255,255,0.2)' : (isDark ? 'rgba(59,130,246,0.1)' : 'rgba(59,130,246,0.08)'),
                    }}
                  >
                    {generating === topic.id ? (
                      <Loader2 className="w-4 h-4 animate-spin" style={{ color: selectedTopic?.id === topic.id && activeTab === 'notes' ? '#fff' : '#3B82F6' }} />
                    ) : (
                      <FileText className="w-4 h-4" style={{ color: selectedTopic?.id === topic.id && activeTab === 'notes' ? '#fff' : '#3B82F6' }} />
                    )}
                  </div>
                  <div className="flex-1 min-w-0">
                    <p className="font-medium text-sm truncate">
                      {topic.title}
                    </p>
                    <p className="text-xs opacity-70">{topic.category}</p>
                  </div>
                  {generatedNotes[topic.id] && (
                    <div className="w-2 h-2 rounded-full bg-green-400" />
                  )}
                </motion.button>
              ))
              )}
            </motion.div>
          </div>

          {/* Main Content */}
          <motion.div initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: 0.3 }}
            className="lg:col-span-3"
          >
            {/* Tab Switcher */}
            <div className="flex gap-2 mb-4">
              <button
                onClick={() => setActiveTab('notes')}
                className="flex items-center gap-2 px-4 py-2 rounded-xl font-medium transition-all"
                style={{
                  background: activeTab === 'notes' ? accent : 'transparent',
                  color: activeTab === 'notes' ? '#fff' : text,
                  border: `1px solid ${activeTab === 'notes' ? accent : border}`
                }}
              >
                <FileText className="w-4 h-4" />
                Study Notes
              </button>
              <button
                onClick={() => setActiveTab('chat')}
                className="flex items-center gap-2 px-4 py-2 rounded-xl font-medium transition-all"
                style={{
                  background: activeTab === 'chat' ? accent : 'transparent',
                  color: activeTab === 'chat' ? '#fff' : text,
                  border: `1px solid ${activeTab === 'chat' ? accent : border}`
                }}
              >
                <MessageSquare className="w-4 h-4" />
                AI Chat
                {messages.length > 0 && (
                  <span className="px-2 py-0.5 rounded-full text-xs bg-white/20">
                    {messages.length}
                  </span>
                )}
              </button>
            </div>

            {/* Notes Tab */}
            {activeTab === 'notes' && (
              <>
                {selectedTopic && generatedNotes[selectedTopic.id] ? (
                  <div className="bg-white dark:bg-gray-900 rounded-2xl shadow-xl border border-gray-200 dark:border-gray-700 overflow-hidden">
                    {/* Header */}
                    <div className="bg-gradient-to-r from-blue-500 to-purple-600 p-6 text-white">
                      <div className="flex items-center justify-between">
                        <div className="flex items-center gap-4">
                          <div className="w-12 h-12 bg-white/20 rounded-xl flex items-center justify-center backdrop-blur-sm">
                            <FileText className="w-6 h-6 text-white" />
                          </div>
                          <div>
                            <h2 className="text-xl font-bold text-white">{selectedTopic.title}</h2>
                            <p className="text-blue-100 text-sm">AI-generated study notes</p>
                          </div>
                        </div>
                        <div className="flex items-center gap-2">
                          <motion.button 
                            whileHover={{ scale: 1.1 }}
                            whileTap={{ scale: 0.9 }}
                            onClick={copyNotes} 
                            className="p-2 bg-white/20 hover:bg-white/30 rounded-lg transition-all backdrop-blur-sm"
                          >
                            {copied ? <Check className="w-4 h-4 text-green-300" /> : <Copy className="w-4 h-4 text-white" />}
                          </motion.button>
                          <motion.button 
                            whileHover={{ scale: 1.1 }}
                            whileTap={{ scale: 0.9 }}
                            onClick={() => generateNotes(selectedTopic)} 
                            className="p-2 bg-white/20 hover:bg-white/30 rounded-lg transition-all backdrop-blur-sm"
                          >
                            <RefreshCw className="w-4 h-4 text-white" />
                          </motion.button>
                        </div>
                      </div>
                    </div>
                    
                    {/* Content */}
                    <div className="p-4 sm:p-6 max-h-[500px] overflow-y-auto">
                      <div className="prose prose-sm sm:prose prose-gray dark:prose-invert max-w-none">
                        <div className="whitespace-pre-wrap font-sans text-xs sm:text-sm leading-relaxed" style={{ color: text }}>
                          {generatedNotes[selectedTopic.id]}
                        </div>
                      </div>
                    </div>
                  </div>
                ) : (
                  <div className="bg-white dark:bg-gray-900 rounded-2xl shadow-xl border border-gray-200 dark:border-gray-700 min-h-[400px] flex flex-col items-center justify-center text-center p-6 sm:p-8">
                    <motion.div 
                      initial={{ scale: 0.8, opacity: 0 }}
                      animate={{ scale: 1, opacity: 1 }}
                      className="w-20 h-20 sm:w-24 sm:h-24 bg-gradient-to-br from-blue-500 to-purple-600 rounded-2xl flex items-center justify-center mb-4 sm:mb-6 shadow-lg"
                    >
                      <FileText className="w-10 h-10 sm:w-12 sm:h-12 text-white" />
                    </motion.div>
                    <h3 className="text-xl sm:text-2xl font-bold mb-2 sm:mb-3" style={{ color: text }}>Select a Topic</h3>
                    <p className="text-sm sm:text-base max-w-md leading-relaxed opacity-70" style={{ color: muted }}>
                      Choose any topic from your roadmap to generate AI-powered study notes instantly.
                    </p>
                  </div>
                )}
              </>
            )}

            {/* Chat Tab */}
            {activeTab === 'chat' && (
              <div className="bg-white dark:bg-gray-900 rounded-2xl shadow-xl border border-gray-200 dark:border-gray-700 overflow-hidden flex flex-col" style={{ height: 'calc(100vh - 400px)', minHeight: '500px' }}>
                {/* Chat Messages */}
                <div 
                  ref={chatContainerRef}
                  onScroll={handleScroll}
                  className="flex-1 overflow-y-auto p-4 relative"
                >
                  {messages.length === 0 ? (
                    <div className="h-full flex flex-col items-center justify-center text-center">
                      <div className="w-20 h-20 rounded-3xl bg-gradient-to-br from-blue-500 to-purple-600 flex items-center justify-center mb-6 shadow-xl">
                        <Bot className="w-10 h-10 text-white" />
                      </div>
                      <h3 className="text-xl font-bold mb-2" style={{ color: text }}>
                        Ask Me Anything!
                      </h3>
                      <p className="text-sm max-w-md" style={{ color: muted }}>
                        I can help you understand concepts, debug code, and answer any programming questions.
                      </p>
                    </div>
                  ) : (
                    <div className="space-y-4">
                      <AnimatePresence>
                        {messages.map((message) => (
                          <motion.div
                            key={message.id}
                            initial={{ opacity: 0, y: 20 }}
                            animate={{ opacity: 1, y: 0 }}
                            exit={{ opacity: 0, y: -20 }}
                            className={`flex gap-3 ${message.role === 'user' ? 'justify-end' : 'justify-start'}`}
                          >
                            {message.role === 'assistant' && (
                              <div className="w-8 h-8 rounded-lg bg-gradient-to-br from-blue-500 to-purple-600 flex items-center justify-center flex-shrink-0 shadow-md">
                                <Bot className="w-4 h-4 text-white" />
                              </div>
                            )}
                            
                            <div 
                              className={`max-w-[80%] rounded-2xl px-4 py-3 relative group ${
                                message.role === 'user' 
                                  ? 'bg-gradient-to-r from-blue-500 to-purple-600 text-white' 
                                  : ''
                              }`}
                              style={message.role === 'assistant' ? { 
                                background: isDark ? 'rgba(255,255,255,0.08)' : 'rgba(0,0,0,0.04)',
                                border: `1px solid ${border}`
                              } : {}}
                            >
                              <div 
                                className="text-sm leading-relaxed whitespace-pre-wrap"
                                style={{ color: message.role === 'user' ? '#fff' : text }}
                              >
                                {message.content}
                              </div>
                              
                              {message.role === 'assistant' && (
                                <div className="flex items-center gap-2 mt-3 pt-2 border-t opacity-0 group-hover:opacity-100 transition-opacity"
                                  style={{ borderColor: border }}
                                >
                                  <button
                                    onClick={() => copyToClipboard(message.id, message.content)}
                                    className="p-1.5 rounded-lg hover:bg-black/10 dark:hover:bg-white/10 transition-colors"
                                  >
                                    {copiedId === message.id ? (
                                      <Check className="w-4 h-4 text-green-500" />
                                    ) : (
                                      <Copy className="w-4 h-4" style={{ color: muted }} />
                                    )}
                                  </button>
                                </div>
                              )}
                            </div>

                            {message.role === 'user' && (
                              <div 
                                className="w-8 h-8 rounded-lg flex items-center justify-center flex-shrink-0 shadow-md"
                                style={{ background: accent }}
                              >
                                <User className="w-4 h-4 text-white" />
                              </div>
                            )}
                          </motion.div>
                        ))}
                      </AnimatePresence>

                      {isLoadingChat && (
                        <motion.div
                          initial={{ opacity: 0, y: 20 }}
                          animate={{ opacity: 1, y: 0 }}
                          className="flex gap-3"
                        >
                          <div className="w-8 h-8 rounded-lg bg-gradient-to-br from-blue-500 to-purple-600 flex items-center justify-center flex-shrink-0 shadow-md">
                            <Bot className="w-4 h-4 text-white" />
                          </div>
                          <div 
                            className="rounded-2xl px-4 py-3"
                            style={{ 
                              background: isDark ? 'rgba(255,255,255,0.08)' : 'rgba(0,0,0,0.04)',
                              border: `1px solid ${border}`
                            }}
                          >
                            <div className="flex items-center gap-2">
                              <div className="flex gap-1">
                                {[0, 1, 2].map((i) => (
                                  <motion.div
                                    key={i}
                                    className="w-2 h-2 rounded-full"
                                    style={{ background: accent }}
                                    animate={{ y: [0, -6, 0] }}
                                    transition={{ duration: 0.6, repeat: Infinity, delay: i * 0.15 }}
                                  />
                                ))}
                              </div>
                              <span className="text-sm" style={{ color: muted }}>Thinking...</span>
                            </div>
                          </div>
                        </motion.div>
                      )}

                      <div ref={messagesEndRef} />
                    </div>
                  )}

                  {showScrollButton && (
                    <motion.button
                      initial={{ opacity: 0, scale: 0.8 }}
                      animate={{ opacity: 1, scale: 1 }}
                      onClick={scrollToBottom}
                      className="absolute bottom-4 right-4 w-10 h-10 rounded-full shadow-lg flex items-center justify-center"
                      style={{ background: accent }}
                    >
                      <ArrowDown className="w-5 h-5 text-white" />
                    </motion.button>
                  )}
                </div>

                {/* Chat Input */}
                <div className="p-3 border-t" style={{ borderColor: border }}>
                  <div className="flex items-end gap-3">
                    {messages.length > 0 && (
                      <button
                        onClick={clearChat}
                        className="p-3 rounded-xl hover:bg-red-500/10 transition-colors flex-shrink-0"
                        title="Clear chat"
                      >
                        <Trash2 className="w-5 h-5 text-red-500" />
                      </button>
                    )}
                    
                    <textarea
                      ref={inputRef}
                      value={input}
                      onChange={handleInputChange}
                      onKeyDown={handleKeyDown}
                      placeholder="Ask anything about programming..."
                      rows={1}
                      className="flex-1 resize-none outline-none text-sm py-3 px-4 rounded-xl"
                      style={{ 
                        background: isDark ? 'rgba(255,255,255,0.05)' : 'rgba(0,0,0,0.03)',
                        color: text,
                        maxHeight: '150px'
                      }}
                    />
                    
                    <motion.button
                      whileHover={{ scale: 1.05 }}
                      whileTap={{ scale: 0.95 }}
                      onClick={() => sendMessage()}
                      disabled={!input.trim() || isLoadingChat}
                      className="p-3 rounded-xl flex-shrink-0 disabled:opacity-50 disabled:cursor-not-allowed"
                      style={{ 
                        background: input.trim() && !isLoadingChat 
                          ? 'linear-gradient(135deg, #3B82F6, #8B5CF6)' 
                          : (isDark ? 'rgba(255,255,255,0.1)' : 'rgba(0,0,0,0.1)')
                      }}
                    >
                      {isLoadingChat ? (
                        <Loader2 className="w-5 h-5 text-white animate-spin" />
                      ) : (
                        <Send className="w-5 h-5 text-white" />
                      )}
                    </motion.button>
                  </div>
                  <p className="text-center text-xs mt-2" style={{ color: muted }}>
                    Press <kbd className="px-1.5 py-0.5 rounded text-xs" style={{ background: border }}>Enter</kbd> to send
                  </p>
                </div>
              </div>
            )}
          </motion.div>
        </div>
        </div>
      </div>
    </PageWrapper>
  )
}
